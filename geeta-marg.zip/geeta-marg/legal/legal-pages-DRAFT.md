# Geeta Marg: Legal pages (DRAFT v1)

Status: DRAFT for Udit's review. Not legal advice. Before public launch, a CA or lawyer should check these, and the company name and address must be filled in.

Company: UN Automation Pvt. Ltd. (once registered). Until then: the operator is Udit Shandilya as an individual.
Contact: [business email, for example unautomation.ops@gmail.com]
Last updated: [date]

---

## 1. Terms of Use

1. **What Geeta Marg is.** Geeta Marg is an AI chat app that shares reflections based on the Bhagavad Gita. It is for personal reflection and learning only.
2. **Not professional advice.** Geeta Marg is not a priest, doctor, lawyer, financial adviser or licensed counsellor. Its guides are AI characters, not real people. Nothing in the app replaces professional help.
3. **Emergencies.** If you are in danger or thinking of harming yourself, contact emergency services (112 in India) or Tele-MANAS (14416) right away. Do not rely on the app.
4. **Accuracy.** We take care with verse references, but AI can make mistakes. Check important points against a trusted source.
5. **Acceptable use.** Do not use the app to harass others, to spread hate against any faith or group, to break the law, or to try to break the service.
6. **Free and paid plans.** Some features may require payment in future. Prices and terms will be shown before you pay.
7. **Your content.** You keep ownership of what you type. You give us permission to process it only to answer you and run the service.
8. **Availability.** The service may change, pause or end. We will give notice where we reasonably can.
9. **Liability.** To the extent the law allows, we are not liable for decisions you make based on the app. Nothing here limits liability that cannot be limited under Indian law.
10. **Governing law.** These terms are governed by the laws of India. Courts in Delhi have jurisdiction.

## 2. Privacy Policy (DPDP Act, 2023, aligned)

1. **What we collect.** The messages you type, the guide you choose, and basic account details (email, name) if you create an account. We do not ask for health records, Aadhaar numbers or bank details in the chat.
2. **Why we use it.** To answer your questions, keep your chosen guide, show your history if you ask, and keep the service safe.
3. **Consent.** You agree to this policy when you start chatting or create an account. You can withdraw consent at any time.
4. **AI providers.** Your messages are sent to an AI provider (Anthropic) to produce answers. We do not sell your data. Our provider agreement limits how they may use it.
5. **Sensitive topics.** If you write about self-harm or crisis, we show a helpline message. We do not store those messages beyond what the service needs in that moment.
6. **Retention.** Chat history is kept for [30 days / until you delete it]. You can delete any conversation or your whole account from the Profile screen.
7. **Your rights.** You can ask us what data we hold, ask us to correct it, and ask us to delete it. Email [business email]. We will respond within a reasonable time, and in any case within the time the law requires.
8. **Children.** Geeta Marg is not designed for children under 13. If you are under 18, please use the app with a parent or guardian.
9. **Security.** We use encryption in transit and access controls. No system is perfectly secure; tell us at once if you think your account is at risk.
10. **Changes.** We will tell you about material changes before they apply.
11. **Grievance officer.** [Name, email]. Responds within the time required by Indian law.

## 3. Refund Policy

1. **Free features.** Nothing to refund.
2. **Paid subscriptions (when launched).** You may cancel at any time. Cancellation stops the next charge.
3. **Refund window.** Request a full refund within 7 days of your first payment if you have used less than [N] messages. Email [business email] with your order details.
4. **Duplicate or failed payments.** Refunded in full, usually within 7 working days, to the original payment method.
5. **Refunds are processed through Razorpay** and may take additional time from your bank.
6. **Pricing changes** will not affect a subscription until its next renewal, and you will be told first.

---

## Items to fill before launch (checklist)
- [ ] Company legal name and registered address (after Udyam/GST)
- [ ] Business contact email
- [ ] Grievance officer name and email
- [ ] Chat history retention period
- [ ] Refund window (number of messages)
- [ ] CA review of refund and tax wording
- [ ] Udit's sign-off on all three pages
